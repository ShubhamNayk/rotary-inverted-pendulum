/*
 * closed_loop_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "closed_loop".
 *
 * Model version              : 18.67
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Nov 15 12:18:39 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef closed_loop_types_h_
#define closed_loop_types_h_

/* Parameters (default storage) */
typedef struct P_closed_loop_T_ P_closed_loop_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_closed_loop_T RT_MODEL_closed_loop_T;

#endif                                 /* closed_loop_types_h_ */
