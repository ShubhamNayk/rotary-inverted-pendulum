/*
 * closed_loop.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "closed_loop".
 *
 * Model version              : 18.67
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Nov 15 12:18:39 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "closed_loop.h"
#include "rtwtypes.h"
#include <math.h>
#include "closed_loop_private.h"
#include "rt_nonfinite.h"
#include <string.h>
#include "closed_loop_dt.h"

/* Named constants for MATLAB Function: '<Root>/MATLAB Function' */
#define closed_loop_CALL_EVENT         (-1)

/* Block signals (default storage) */
B_closed_loop_T closed_loop_B;

/* Continuous states */
X_closed_loop_T closed_loop_X;

/* Disabled State Vector */
XDis_closed_loop_T closed_loop_XDis;

/* Block states (default storage) */
DW_closed_loop_T closed_loop_DW;

/* Real-time model */
static RT_MODEL_closed_loop_T closed_loop_M_;
RT_MODEL_closed_loop_T *const closed_loop_M = &closed_loop_M_;

/* Forward declaration for local functions */
static real_T closed_loop_mod(real_T x);

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  closed_loop_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T closed_loop_mod(real_T x)
{
  real_T r;
  if (rtIsNaN(x) || rtIsInf(x)) {
    r = (rtNaN);
  } else if (x == 0.0) {
    r = 0.0;
  } else {
    boolean_T rEQ0;
    r = fmod(x, 6.2831853071795862);
    rEQ0 = (r == 0.0);
    if (!rEQ0) {
      real_T q;
      q = fabs(x / 6.2831853071795862);
      rEQ0 = !(fabs(q - floor(q + 0.5)) > 2.2204460492503131E-16 * q);
    }

    if (rEQ0) {
      r = 0.0;
    } else if (r < 0.0) {
      r += 6.2831853071795862;
    }
  }

  return r;
}

/* Model output function */
void closed_loop_output(void)
{
  real_T Eref;
  real_T rtb_HILReadEncoderTimebase_o1;
  real_T rtb_Saturation;
  boolean_T tmp;
  if (rtmIsMajorTimeStep(closed_loop_M)) {
    /* set solver stop time */
    if (!(closed_loop_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&closed_loop_M->solverInfo,
                            ((closed_loop_M->Timing.clockTickH0 + 1) *
        closed_loop_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&closed_loop_M->solverInfo,
                            ((closed_loop_M->Timing.clockTick0 + 1) *
        closed_loop_M->Timing.stepSize0 + closed_loop_M->Timing.clockTickH0 *
        closed_loop_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(closed_loop_M)) {
    closed_loop_M->Timing.t[0] = rtsiGetT(&closed_loop_M->solverInfo);
  }

  tmp = rtmIsMajorTimeStep(closed_loop_M);
  if (tmp) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

    /* S-Function Block: closed_loop/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder(closed_loop_DW.HILReadEncoderTimebase_Task,
        1, &closed_loop_DW.HILReadEncoderTimebase_Buffer[0]);
      if (result < 0) {
        rtb_HILReadEncoderTimebase_o1 = 0;
        rtb_Saturation = 0;
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      } else {
        rtb_HILReadEncoderTimebase_o1 =
          closed_loop_DW.HILReadEncoderTimebase_Buffer[0];
        rtb_Saturation = closed_loop_DW.HILReadEncoderTimebase_Buffer[1];
      }
    }

    /* Gain: '<Root>/Gain' */
    closed_loop_B.Gain = closed_loop_P.Gain_Gain * rtb_HILReadEncoderTimebase_o1;

    /* Gain: '<Root>/Gain1' */
    closed_loop_B.Gain1 = closed_loop_P.Gain1_Gain * rtb_Saturation;
  }

  /* TransferFcn: '<Root>/Transfer Fcn' */
  closed_loop_B.TransferFcn = 0.0;
  closed_loop_B.TransferFcn += closed_loop_P.TransferFcn_C *
    closed_loop_X.TransferFcn_CSTATE;
  closed_loop_B.TransferFcn += closed_loop_P.TransferFcn_D * closed_loop_B.Gain;

  /* TransferFcn: '<Root>/Transfer Fcn1' */
  closed_loop_B.TransferFcn1 = 0.0;
  closed_loop_B.TransferFcn1 += closed_loop_P.TransferFcn1_C *
    closed_loop_X.TransferFcn1_CSTATE;
  closed_loop_B.TransferFcn1 += closed_loop_P.TransferFcn1_D *
    closed_loop_B.Gain1;
  if (tmp) {
    /* MATLAB Function: '<Root>/MATLAB Function' incorporates:
     *  SignalConversion generated from: '<S1>/ SFunction '
     */
    closed_loop_DW.sfEvent = closed_loop_CALL_EVENT;

    /* MATLAB Function 'MATLAB Function': '<S1>:1' */
    /* '<S1>:1:8' */
    /* '<S1>:1:10' */
    /* '<S1>:1:11' */
    /* '<S1>:1:12' */
    /* '<S1>:1:13' */
    /* '<S1>:1:14' */
    /* '<S1>:1:17' */
    /* '<S1>:1:18' */
    /* '<S1>:1:19' */
    rtb_HILReadEncoderTimebase_o1 = closed_loop_mod(closed_loop_B.Gain1 + 0.007)
      - 3.1415926535897931;

    /* '<S1>:1:20' */
    /* '<S1>:1:26' */
    closed_loop_DW.k++;
    if (fabs(closed_loop_B.Gain) > 6.0) {
      /* '<S1>:1:28' */
      closed_loop_DW.tripped = 1.0;
    }

    if (closed_loop_DW.tripped != 0.0) {
      /* '<S1>:1:29' */
      closed_loop_B.Voltage = 0.0;
    } else {
      if ((closed_loop_DW.mode == 0.0) && (fabs(rtb_HILReadEncoderTimebase_o1) <
           closed_loop_P.epsilon)) {
        /* '<S1>:1:42' */
        /* '<S1>:1:43' */
        closed_loop_DW.mode = 1.0;
      } else if ((closed_loop_DW.mode == 1.0) && (fabs
                  (rtb_HILReadEncoderTimebase_o1) > 0.6)) {
        /* '<S1>:1:44' */
        /* '<S1>:1:45' */
        closed_loop_DW.mode = 0.0;
      }

      if (closed_loop_DW.mode == 1.0) {
        /* '<S1>:1:47' */
        /* '<S1>:1:49' */
        closed_loop_B.Voltage = ((-closed_loop_P.K_lqr[0] * closed_loop_B.Gain +
          -closed_loop_P.K_lqr[1] * rtb_HILReadEncoderTimebase_o1) +
          -closed_loop_P.K_lqr[2] * closed_loop_B.TransferFcn) +
          -closed_loop_P.K_lqr[3] * closed_loop_B.TransferFcn1;
      } else {
        /* '<S1>:1:54' */
        /* '<S1>:1:55' */
        rtb_Saturation = cos(closed_loop_mod(closed_loop_B.Gain1 +
          3.1415926535897931) - 3.1415926535897931);
        rtb_HILReadEncoderTimebase_o1 = closed_loop_B.TransferFcn1 *
          closed_loop_B.TransferFcn1 * 6.6565E-5 + (1.0 - rtb_Saturation) *
          0.015186;

        /* '<S1>:1:56' */
        rtb_Saturation *= closed_loop_B.TransferFcn1;

        /* '<S1>:1:56' */
        /* '<S1>:1:57' */
        Eref = 1.05 * closed_loop_P.Er;
        if (rtb_HILReadEncoderTimebase_o1 < Eref) {
          /* '<S1>:1:58' */
          rtb_HILReadEncoderTimebase_o1 = (Eref - rtb_HILReadEncoderTimebase_o1)
            * closed_loop_P.mu * (rtb_Saturation / (fabs(rtb_Saturation) + 0.05));
        } else {
          /* '<S1>:1:58' */
          rtb_HILReadEncoderTimebase_o1 = 0.0;
        }

        /* '<S1>:1:59' */
        /* '<S1>:1:60' */
        closed_loop_B.Voltage = fmin(fmax((rtb_HILReadEncoderTimebase_o1 - 0.5 *
          closed_loop_B.Gain) - 0.05 * closed_loop_B.TransferFcn, -6.0), 6.0);
      }
    }

    /* End of MATLAB Function: '<Root>/MATLAB Function' */

    /* Saturate: '<Root>/Saturation' */
    if (closed_loop_B.Voltage > closed_loop_P.Saturation_UpperSat) {
      rtb_Saturation = closed_loop_P.Saturation_UpperSat;
    } else if (closed_loop_B.Voltage < closed_loop_P.Saturation_LowerSat) {
      rtb_Saturation = closed_loop_P.Saturation_LowerSat;
    } else {
      rtb_Saturation = closed_loop_B.Voltage;
    }

    /* End of Saturate: '<Root>/Saturation' */

    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: closed_loop/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(closed_loop_DW.HILInitialize_Card,
        &closed_loop_P.HILWriteAnalog_channels, 1, &rtb_Saturation);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      }
    }
  }
}

/* Model update function */
void closed_loop_update(void)
{
  if (rtmIsMajorTimeStep(closed_loop_M)) {
    rt_ertODEUpdateContinuousStates(&closed_loop_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++closed_loop_M->Timing.clockTick0)) {
    ++closed_loop_M->Timing.clockTickH0;
  }

  closed_loop_M->Timing.t[0] = rtsiGetSolverStopTime(&closed_loop_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.002s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++closed_loop_M->Timing.clockTick1)) {
      ++closed_loop_M->Timing.clockTickH1;
    }

    closed_loop_M->Timing.t[1] = closed_loop_M->Timing.clockTick1 *
      closed_loop_M->Timing.stepSize1 + closed_loop_M->Timing.clockTickH1 *
      closed_loop_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void closed_loop_derivatives(void)
{
  XDot_closed_loop_T *_rtXdot;
  _rtXdot = ((XDot_closed_loop_T *) closed_loop_M->derivs);

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = closed_loop_P.TransferFcn_A *
    closed_loop_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += closed_loop_B.Gain;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn1' */
  _rtXdot->TransferFcn1_CSTATE = closed_loop_P.TransferFcn1_A *
    closed_loop_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE += closed_loop_B.Gain1;
}

/* Model initialize function */
void closed_loop_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: closed_loop/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("qube_servo3_usb", "0", &closed_loop_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(closed_loop_DW.HILInitialize_Card,
      "deadband_compensation=0;pwm_en=0;enc0_velocity=3.0;enc1_velocity=3.0;min_diode_compensation=0.3;max_diode_compensation=1.5;",
      124);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(closed_loop_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      return;
    }

    if ((closed_loop_P.HILInitialize_AIPStart && !is_switching) ||
        (closed_loop_P.HILInitialize_AIPEnter && is_switching)) {
      result = hil_set_analog_input_ranges(closed_loop_DW.HILInitialize_Card,
        &closed_loop_P.HILInitialize_AIChannels, 1U,
        &closed_loop_P.HILInitialize_AILow, &closed_loop_P.HILInitialize_AIHigh);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if ((closed_loop_P.HILInitialize_AOPStart && !is_switching) ||
        (closed_loop_P.HILInitialize_AOPEnter && is_switching)) {
      result = hil_set_analog_output_ranges(closed_loop_DW.HILInitialize_Card,
        &closed_loop_P.HILInitialize_AOChannels, 1U,
        &closed_loop_P.HILInitialize_AOLow, &closed_loop_P.HILInitialize_AOHigh);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if ((closed_loop_P.HILInitialize_AOStart && !is_switching) ||
        (closed_loop_P.HILInitialize_AOEnter && is_switching)) {
      result = hil_write_analog(closed_loop_DW.HILInitialize_Card,
        &closed_loop_P.HILInitialize_AOChannels, 1U,
        &closed_loop_P.HILInitialize_AOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if (closed_loop_P.HILInitialize_AOReset) {
      result = hil_watchdog_set_analog_expiration_state
        (closed_loop_DW.HILInitialize_Card,
         &closed_loop_P.HILInitialize_AOChannels, 1U,
         &closed_loop_P.HILInitialize_AOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    result = hil_set_digital_directions(closed_loop_DW.HILInitialize_Card, NULL,
      0U, &closed_loop_P.HILInitialize_DOChannels, 1U);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(closed_loop_M, _rt_error_message);
      return;
    }

    if ((closed_loop_P.HILInitialize_DOStart && !is_switching) ||
        (closed_loop_P.HILInitialize_DOEnter && is_switching)) {
      result = hil_write_digital(closed_loop_DW.HILInitialize_Card,
        &closed_loop_P.HILInitialize_DOChannels, 1U, (t_boolean *)
        &closed_loop_P.HILInitialize_DOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if (closed_loop_P.HILInitialize_DOReset) {
      result = hil_watchdog_set_digital_expiration_state
        (closed_loop_DW.HILInitialize_Card,
         &closed_loop_P.HILInitialize_DOChannels, 1U, (const t_digital_state *)
         &closed_loop_P.HILInitialize_DOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if ((closed_loop_P.HILInitialize_EIPStart && !is_switching) ||
        (closed_loop_P.HILInitialize_EIPEnter && is_switching)) {
      closed_loop_DW.HILInitialize_QuadratureModes[0] =
        closed_loop_P.HILInitialize_EIQuadrature;
      closed_loop_DW.HILInitialize_QuadratureModes[1] =
        closed_loop_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode(closed_loop_DW.HILInitialize_Card,
        closed_loop_P.HILInitialize_EIChannels, 2U, (t_encoder_quadrature_mode *)
        &closed_loop_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if ((closed_loop_P.HILInitialize_EIStart && !is_switching) ||
        (closed_loop_P.HILInitialize_EIEnter && is_switching)) {
      closed_loop_DW.HILInitialize_InitialEICounts[0] =
        closed_loop_P.HILInitialize_EIInitial;
      closed_loop_DW.HILInitialize_InitialEICounts[1] =
        closed_loop_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts(closed_loop_DW.HILInitialize_Card,
        closed_loop_P.HILInitialize_EIChannels, 2U,
        &closed_loop_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if ((closed_loop_P.HILInitialize_OOStart && !is_switching) ||
        (closed_loop_P.HILInitialize_OOEnter && is_switching)) {
      result = hil_write_other(closed_loop_DW.HILInitialize_Card,
        closed_loop_P.HILInitialize_OOChannels, 3U,
        closed_loop_P.HILInitialize_OOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }

    if (closed_loop_P.HILInitialize_OOReset) {
      result = hil_watchdog_set_other_expiration_state
        (closed_loop_DW.HILInitialize_Card,
         closed_loop_P.HILInitialize_OOChannels, 3U,
         closed_loop_P.HILInitialize_OOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: closed_loop/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader(closed_loop_DW.HILInitialize_Card,
      closed_loop_P.HILReadEncoderTimebase_SamplesI,
      closed_loop_P.HILReadEncoderTimebase_Channels, 2,
      &closed_loop_DW.HILReadEncoderTimebase_Task);
    if (result >= 0) {
      result = hil_task_set_buffer_overflow_mode
        (closed_loop_DW.HILReadEncoderTimebase_Task, (t_buffer_overflow_mode)
         (closed_loop_P.HILReadEncoderTimebase_Overflow - 1));
    }

    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(closed_loop_M, _rt_error_message);
    }
  }

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn' */
  closed_loop_X.TransferFcn_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn1' */
  closed_loop_X.TransferFcn1_CSTATE = 0.0;

  /* SystemInitialize for MATLAB Function: '<Root>/MATLAB Function' */
  closed_loop_DW.mode = 0.0;
  closed_loop_DW.mode_not_empty = true;
  closed_loop_DW.k = 0.0;
  closed_loop_DW.k_not_empty = true;
  closed_loop_DW.tripped = 0.0;
  closed_loop_DW.tripped_not_empty = true;
  closed_loop_DW.doneDoubleBufferReInit = false;
  closed_loop_DW.sfEvent = closed_loop_CALL_EVENT;
}

/* Model terminate function */
void closed_loop_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: closed_loop/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_digital_outputs = 0;
    t_uint32 num_final_other_outputs = 0;
    hil_task_stop_all(closed_loop_DW.HILInitialize_Card);
    hil_monitor_stop_all(closed_loop_DW.HILInitialize_Card);
    is_switching = false;
    if ((closed_loop_P.HILInitialize_AOTerminate && !is_switching) ||
        (closed_loop_P.HILInitialize_AOExit && is_switching)) {
      num_final_analog_outputs = 1U;
    } else {
      num_final_analog_outputs = 0;
    }

    if ((closed_loop_P.HILInitialize_DOTerminate && !is_switching) ||
        (closed_loop_P.HILInitialize_DOExit && is_switching)) {
      num_final_digital_outputs = 1U;
    } else {
      num_final_digital_outputs = 0;
    }

    if ((closed_loop_P.HILInitialize_OOTerminate && !is_switching) ||
        (closed_loop_P.HILInitialize_OOExit && is_switching)) {
      num_final_other_outputs = 3U;
    } else {
      num_final_other_outputs = 0;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_digital_outputs > 0
        || num_final_other_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(closed_loop_DW.HILInitialize_Card
                         , &closed_loop_P.HILInitialize_AOChannels,
                         num_final_analog_outputs
                         , NULL, 0
                         , &closed_loop_P.HILInitialize_DOChannels,
                         num_final_digital_outputs
                         , closed_loop_P.HILInitialize_OOChannels,
                         num_final_other_outputs
                         , &closed_loop_P.HILInitialize_AOFinal
                         , NULL
                         , (t_boolean *) &closed_loop_P.HILInitialize_DOFinal
                         , closed_loop_P.HILInitialize_OOFinal
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(closed_loop_DW.HILInitialize_Card,
            &closed_loop_P.HILInitialize_AOChannels, num_final_analog_outputs,
            &closed_loop_P.HILInitialize_AOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_digital_outputs > 0) {
          local_result = hil_write_digital(closed_loop_DW.HILInitialize_Card,
            &closed_loop_P.HILInitialize_DOChannels, num_final_digital_outputs,
            (t_boolean *) &closed_loop_P.HILInitialize_DOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_other_outputs > 0) {
          local_result = hil_write_other(closed_loop_DW.HILInitialize_Card,
            closed_loop_P.HILInitialize_OOChannels, num_final_other_outputs,
            closed_loop_P.HILInitialize_OOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(closed_loop_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(closed_loop_DW.HILInitialize_Card);
    hil_monitor_delete_all(closed_loop_DW.HILInitialize_Card);
    hil_close(closed_loop_DW.HILInitialize_Card);
    closed_loop_DW.HILInitialize_Card = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  closed_loop_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  closed_loop_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  closed_loop_initialize();
}

void MdlTerminate(void)
{
  closed_loop_terminate();
}

/* Registration function */
RT_MODEL_closed_loop_T *closed_loop(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)closed_loop_M, 0,
                sizeof(RT_MODEL_closed_loop_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&closed_loop_M->solverInfo,
                          &closed_loop_M->Timing.simTimeStep);
    rtsiSetTPtr(&closed_loop_M->solverInfo, &rtmGetTPtr(closed_loop_M));
    rtsiSetStepSizePtr(&closed_loop_M->solverInfo,
                       &closed_loop_M->Timing.stepSize0);
    rtsiSetdXPtr(&closed_loop_M->solverInfo, &closed_loop_M->derivs);
    rtsiSetContStatesPtr(&closed_loop_M->solverInfo, (real_T **)
                         &closed_loop_M->contStates);
    rtsiSetNumContStatesPtr(&closed_loop_M->solverInfo,
      &closed_loop_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&closed_loop_M->solverInfo,
      &closed_loop_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&closed_loop_M->solverInfo,
      &closed_loop_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&closed_loop_M->solverInfo,
      &closed_loop_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&closed_loop_M->solverInfo, (boolean_T**)
      &closed_loop_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&closed_loop_M->solverInfo, (&rtmGetErrorStatus
      (closed_loop_M)));
    rtsiSetRTModelPtr(&closed_loop_M->solverInfo, closed_loop_M);
  }

  rtsiSetSimTimeStep(&closed_loop_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&closed_loop_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&closed_loop_M->solverInfo, false);
  closed_loop_M->intgData.f[0] = closed_loop_M->odeF[0];
  closed_loop_M->contStates = ((real_T *) &closed_loop_X);
  closed_loop_M->contStateDisabled = ((boolean_T *) &closed_loop_XDis);
  closed_loop_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&closed_loop_M->solverInfo, (void *)&closed_loop_M->intgData);
  rtsiSetSolverName(&closed_loop_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = closed_loop_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    closed_loop_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    closed_loop_M->Timing.sampleTimes = (&closed_loop_M->
      Timing.sampleTimesArray[0]);
    closed_loop_M->Timing.offsetTimes = (&closed_loop_M->
      Timing.offsetTimesArray[0]);

    /* task periods */
    closed_loop_M->Timing.sampleTimes[0] = (0.0);
    closed_loop_M->Timing.sampleTimes[1] = (0.002);

    /* task offsets */
    closed_loop_M->Timing.offsetTimes[0] = (0.0);
    closed_loop_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(closed_loop_M, &closed_loop_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = closed_loop_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    closed_loop_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(closed_loop_M, -1);
  closed_loop_M->Timing.stepSize0 = 0.002;
  closed_loop_M->Timing.stepSize1 = 0.002;

  /* External mode info */
  closed_loop_M->Sizes.checksums[0] = (1489609270U);
  closed_loop_M->Sizes.checksums[1] = (3137092824U);
  closed_loop_M->Sizes.checksums[2] = (3343352931U);
  closed_loop_M->Sizes.checksums[3] = (2779296181U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    closed_loop_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(closed_loop_M->extModeInfo,
      &closed_loop_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(closed_loop_M->extModeInfo,
                        closed_loop_M->Sizes.checksums);
    rteiSetTPtr(closed_loop_M->extModeInfo, rtmGetTPtr(closed_loop_M));
  }

  closed_loop_M->solverInfoPtr = (&closed_loop_M->solverInfo);
  closed_loop_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&closed_loop_M->solverInfo, 0.002);
  rtsiSetSolverMode(&closed_loop_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  closed_loop_M->blockIO = ((void *) &closed_loop_B);
  (void) memset(((void *) &closed_loop_B), 0,
                sizeof(B_closed_loop_T));

  /* parameters */
  closed_loop_M->defaultParam = ((real_T *)&closed_loop_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &closed_loop_X;
    closed_loop_M->contStates = (x);
    (void) memset((void *)&closed_loop_X, 0,
                  sizeof(X_closed_loop_T));
  }

  /* disabled states */
  {
    boolean_T *xdis = (boolean_T *) &closed_loop_XDis;
    closed_loop_M->contStateDisabled = (xdis);
    (void) memset((void *)&closed_loop_XDis, 0,
                  sizeof(XDis_closed_loop_T));
  }

  /* states (dwork) */
  closed_loop_M->dwork = ((void *) &closed_loop_DW);
  (void) memset((void *)&closed_loop_DW, 0,
                sizeof(DW_closed_loop_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    closed_loop_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 22;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  closed_loop_M->Sizes.numContStates = (2);/* Number of continuous states */
  closed_loop_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  closed_loop_M->Sizes.numY = (0);     /* Number of model outputs */
  closed_loop_M->Sizes.numU = (0);     /* Number of model inputs */
  closed_loop_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  closed_loop_M->Sizes.numSampTimes = (2);/* Number of sample times */
  closed_loop_M->Sizes.numBlocks = (12);/* Number of blocks */
  closed_loop_M->Sizes.numBlockIO = (5);/* Number of block outputs */
  closed_loop_M->Sizes.numBlockPrms = (122);/* Sum of parameter "widths" */
  return closed_loop_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
