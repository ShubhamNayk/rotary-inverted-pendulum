%% pendulam_setup.m
clear; clc;

%% 1. Physical parameters (Quanser QUBE-Servo 3 workbook values)
mp  = 0.024;    % kg      pendulum mass
Lp  = 0.129;    % m       pendulum length (pivot to tip)
mr  = 0.095;    % kg      arm mass
Lr  = 0.085;    % m       arm length (pivot to tip)
Rm  = 8.4;      % ohm     motor resistance
kt  = 0.042;    % N.m/A   torque constant
km  = 0.042;    % V.s/rad back-EMF constant
Dr  = 0.0015;   % N.m.s   arm viscous damping
Dp  = 0.0005;   % N.m.s   pendulum damping
Jm  = 4e-6;     % kg.m^2  rotor inertia
g   = 9.81;     % m/s^2

lp  = Lp/2;                  % 0.0645 m   pivot to pendulum centre of mass
Jpc = mp*Lp^2/12;            % 3.3282e-5  pendulum inertia about its centre
Jr  = mr*Lr^2/3 + Jm;        % 2.3279e-4  arm inertia about the motor axis
Jpv = Jpc + mp*lp^2;         % 1.3313e-4  pendulum inertia about the pivot

%% 2. Linearised plant about the upright equilibrium (alpha_up = 0)
M11 = Jr + mp*Lr^2;
M12 = mp*Lr*lp;
M22 = Jpv;
dt  = M11*M22 - M12^2;

A = [0, 0,                      1,           0;
     0, 0,                      0,           1;
     0, -M12*g*lp*mp/dt,  -M22*Dr/dt,   M12*Dp/dt;
     0,  M11*g*lp*mp/dt,   M12*Dr/dt,  -M11*Dp/dt];
Bt = [0; 0; M22/dt; -M12/dt];
A(:,3) = A(:,3) + Bt*(-kt*km/Rm);
B  = Bt*(kt/Rm);
C  = [1 0 0 0; 0 1 0 0];
D  = [0; 0];

%% 3. LQR Balance Controller
% Tuned for smooth capture and tight arm regulation
Q = diag([5, 30, 1, 1]);
R = 1.0;
K_lqr = lqr(A, B, Q, R);
fprintf('K_lqr = [%.4f, %.4f, %.4f, %.4f]\n', K_lqr);

%% 4. Swing-Up Parameters (True Joules)
Er      = 2 * mp * g * lp;   % FIXED: 0.03037 Joules (30.37 mJ)
mu      = 2000;                % Energy pump gain (tune between 50 and 90 on hardware)
epsilon = 0.35;              % Capture angle: 0.35 rad (~20 deg)
fprintf('Er = %.5f J (%.2f mJ)\n', Er, Er*1000);

%% 5. Reference H-infinity Controller (Discrete, 500 Hz, Order 6)
Ts = 0.002;

Ad = [ 8.577821796474e-01  1.533791023328e-02 -2.297006744357e-01 -6.663343333518e-01  7.949119883458e-03 -5.065646476823e-03
      -7.297864458473e-01  8.577821161901e-01 -1.086316061499e+00 -4.498767133287e+00 -4.287123768078e-03 -2.157449864439e-02
      -1.350515160261e-08  1.987284635311e-08  9.834763067294e-01 -1.401603847642e-01 -2.341002989371e-03  2.590565173074e-04
      -5.823446417518e-09  3.694893322488e-09  2.785249834251e-04  9.834763298158e-01 -5.386286498041e-04 -6.061665874495e-05
       1.156643558776e-09 -1.949815995346e-09  3.049862075538e-09  3.609664410263e-09  9.999000047307e-01 -2.934646882555e-09
       2.392608440032e-10 -3.777247102601e-10  5.998467405512e-10  6.939713321784e-10 -1.767211473429e-11  9.999000204253e-01];

Bd = [ 6.820591288437e-01 -1.560938459599e+00
       4.588561565261e+00 -4.717087462115e+00
       1.429695088551e-01  3.435243015022e-01
       1.632004302405e-02 -1.485069801967e-02
      -3.843884203770e-04  9.582594887500e-10
       1.962658452649e-03  1.841247634080e-07];

Cd = [ 2.094802115075e-01 -1.681745221988e+00  5.977035001740e+00 ...
       2.052448254669e+01 -9.261075165836e-02  9.910287639802e-02];

Dd = [-2.083427962924e+01  2.696128895921e+01];

enc_res = 2*pi/2048;
Vmax    = 10;