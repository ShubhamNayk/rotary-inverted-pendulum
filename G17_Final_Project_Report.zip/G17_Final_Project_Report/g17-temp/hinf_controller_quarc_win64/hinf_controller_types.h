/*
 * hinf_controller_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "hinf_controller".
 *
 * Model version              : 18.17
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Nov 15 13:41:53 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef hinf_controller_types_h_
#define hinf_controller_types_h_

/* Parameters (default storage) */
typedef struct P_hinf_controller_T_ P_hinf_controller_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_hinf_controller_T RT_MODEL_hinf_controller_T;

#endif                                 /* hinf_controller_types_h_ */
