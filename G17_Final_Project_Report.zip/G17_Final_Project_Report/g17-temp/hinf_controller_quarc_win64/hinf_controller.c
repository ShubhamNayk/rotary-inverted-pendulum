/*
 * hinf_controller.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "hinf_controller".
 *
 * Model version              : 18.17
 * Simulink Coder version : 24.2 (R2024b) 21-Jun-2024
 * C source code generated on : Sun Nov 15 13:41:53 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "hinf_controller.h"
#include "rtwtypes.h"
#include <math.h>
#include <emmintrin.h>
#include "hinf_controller_private.h"
#include "rt_nonfinite.h"
#include <string.h>
#include "hinf_controller_dt.h"

/* Named constants for MATLAB Function: '<Root>/MATLAB Function' */
#define hinf_controller_CALL_EVENT     (-1)

/* Block signals (default storage) */
B_hinf_controller_T hinf_controller_B;

/* Continuous states */
X_hinf_controller_T hinf_controller_X;

/* Disabled State Vector */
XDis_hinf_controller_T hinf_controller_XDis;

/* Block states (default storage) */
DW_hinf_controller_T hinf_controller_DW;

/* Real-time model */
static RT_MODEL_hinf_controller_T hinf_controller_M_;
RT_MODEL_hinf_controller_T *const hinf_controller_M = &hinf_controller_M_;

/* Forward declaration for local functions */
static real_T hinf_controller_mod(real_T x);

/*
 * This function updates continuous states using the ODE4 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = (ODE4_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  hinf_controller_derivatives();

  /* f1 = f(t + (h/2), y + (h/2)*f0) */
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  hinf_controller_output();
  hinf_controller_derivatives();

  /* f2 = f(t + (h/2), y + (h/2)*f1) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  hinf_controller_output();
  hinf_controller_derivatives();

  /* f3 = f(t + h, y + h*f2) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  hinf_controller_output();
  hinf_controller_derivatives();

  /* tnew = t + h
     ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3) */
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Function for MATLAB Function: '<Root>/MATLAB Function' */
static real_T hinf_controller_mod(real_T x)
{
  real_T r;
  if (rtIsNaN(x) || rtIsInf(x)) {
    r = (rtNaN);
  } else if (x == 0.0) {
    r = 0.0;
  } else {
    boolean_T rEQ0;
    r = fmod(x, 6.2831853071795862);
    rEQ0 = (r == 0.0);
    if (!rEQ0) {
      real_T q;
      q = fabs(x / 6.2831853071795862);
      rEQ0 = !(fabs(q - floor(q + 0.5)) > 2.2204460492503131E-16 * q);
    }

    if (rEQ0) {
      r = 0.0;
    } else if (r < 0.0) {
      r += 6.2831853071795862;
    }
  }

  return r;
}

/* Model output function */
void hinf_controller_output(void)
{
  __m128d tmp_3;
  __m128d tmp_4;
  real_T tmp_0[6];
  real_T tmp_1[6];
  real_T Eref;
  real_T rtb_HILReadEncoderTimebase_o1;
  real_T rtb_Saturation;
  real_T tmp_2;
  int32_T i;
  int32_T i_0;
  boolean_T tmp;
  if (rtmIsMajorTimeStep(hinf_controller_M)) {
    /* set solver stop time */
    if (!(hinf_controller_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&hinf_controller_M->solverInfo,
                            ((hinf_controller_M->Timing.clockTickH0 + 1) *
        hinf_controller_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&hinf_controller_M->solverInfo,
                            ((hinf_controller_M->Timing.clockTick0 + 1) *
        hinf_controller_M->Timing.stepSize0 +
        hinf_controller_M->Timing.clockTickH0 *
        hinf_controller_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(hinf_controller_M)) {
    hinf_controller_M->Timing.t[0] = rtsiGetT(&hinf_controller_M->solverInfo);
  }

  tmp = rtmIsMajorTimeStep(hinf_controller_M);
  if (tmp) {
    /* S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

    /* S-Function Block: hinf_controller/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder
        (hinf_controller_DW.HILReadEncoderTimebase_Task, 1,
         &hinf_controller_DW.HILReadEncoderTimebase_Buffer[0]);
      if (result < 0) {
        rtb_HILReadEncoderTimebase_o1 = 0;
        rtb_Saturation = 0;
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      } else {
        rtb_HILReadEncoderTimebase_o1 =
          hinf_controller_DW.HILReadEncoderTimebase_Buffer[0];
        rtb_Saturation = hinf_controller_DW.HILReadEncoderTimebase_Buffer[1];
      }
    }

    /* Gain: '<Root>/Gain' */
    hinf_controller_B.Gain = hinf_controller_P.Gain_Gain *
      rtb_HILReadEncoderTimebase_o1;

    /* Gain: '<Root>/Gain1' */
    hinf_controller_B.Gain1 = hinf_controller_P.Gain1_Gain * rtb_Saturation;
  }

  /* TransferFcn: '<Root>/Transfer Fcn' */
  hinf_controller_B.TransferFcn = 0.0;
  hinf_controller_B.TransferFcn += hinf_controller_P.TransferFcn_C *
    hinf_controller_X.TransferFcn_CSTATE;
  hinf_controller_B.TransferFcn += hinf_controller_P.TransferFcn_D *
    hinf_controller_B.Gain;

  /* TransferFcn: '<Root>/Transfer Fcn1' */
  hinf_controller_B.TransferFcn1 = 0.0;
  hinf_controller_B.TransferFcn1 += hinf_controller_P.TransferFcn1_C *
    hinf_controller_X.TransferFcn1_CSTATE;
  hinf_controller_B.TransferFcn1 += hinf_controller_P.TransferFcn1_D *
    hinf_controller_B.Gain1;
  if (tmp) {
    /* MATLAB Function: '<Root>/MATLAB Function' incorporates:
     *  SignalConversion generated from: '<S1>/ SFunction '
     */
    hinf_controller_DW.sfEvent = hinf_controller_CALL_EVENT;

    /* MATLAB Function 'MATLAB Function': '<S1>:1' */
    /* '<S1>:1:11' */
    /* '<S1>:1:13' */
    /* '<S1>:1:14' */
    /* '<S1>:1:15' */
    /* '<S1>:1:16' */
    /* '<S1>:1:17' */
    /* '<S1>:1:20' */
    /* '<S1>:1:21' */
    /* '<S1>:1:23' */
    /* '<S1>:1:24' */
    /* '<S1>:1:25' */
    rtb_HILReadEncoderTimebase_o1 = hinf_controller_mod(hinf_controller_B.Gain1
      + 0.007) - 3.1415926535897931;

    /* '<S1>:1:26' */
    /* '<S1>:1:34' */
    hinf_controller_DW.k++;
    if (fabs(hinf_controller_B.Gain) > 6.0) {
      /* '<S1>:1:36' */
      hinf_controller_DW.tripped = 1.0;
    }

    if (hinf_controller_DW.tripped != 0.0) {
      /* '<S1>:1:37' */
      hinf_controller_B.Voltage = 0.0;
    } else {
      if ((hinf_controller_DW.mode == 0.0) && (fabs
           (rtb_HILReadEncoderTimebase_o1) < hinf_controller_P.epsilon)) {
        /* '<S1>:1:50' */
        /* '<S1>:1:51' */
        hinf_controller_DW.mode = 1.0;

        /* '<S1>:1:52' */
        for (i = 0; i < 6; i++) {
          hinf_controller_DW.xk[i] = 0.0;
        }

        /* '<S1>:1:53' */
        hinf_controller_DW.th_ref = hinf_controller_B.Gain;
      } else if ((hinf_controller_DW.mode == 1.0) && (fabs
                  (rtb_HILReadEncoderTimebase_o1) > 0.6)) {
        /* '<S1>:1:54' */
        /* '<S1>:1:55' */
        hinf_controller_DW.mode = 0.0;
      }

      if (hinf_controller_DW.mode == 1.0) {
        /* '<S1>:1:57' */
        /* '<S1>:1:59' */
        hinf_controller_DW.th_ref -= fmin(fmax(hinf_controller_DW.th_ref,
          -0.0006), 0.0006);

        /* '<S1>:1:60' */
        rtb_Saturation = hinf_controller_B.Gain - hinf_controller_DW.th_ref;

        /* '<S1>:1:61' */
        Eref = 0.0;

        /* '<S1>:1:62' */
        for (i = 0; i < 6; i++) {
          Eref += hinf_controller_P.Cd[i] * hinf_controller_DW.xk[i];
          tmp_2 = 0.0;
          for (i_0 = 0; i_0 < 6; i_0++) {
            tmp_2 += hinf_controller_P.Ad[6 * i_0 + i] *
              hinf_controller_DW.xk[i_0];
          }

          tmp_0[i] = tmp_2;
          tmp_1[i] = hinf_controller_P.Bd[i + 6] * rtb_HILReadEncoderTimebase_o1
            + hinf_controller_P.Bd[i] * rtb_Saturation;
        }

        hinf_controller_B.Voltage = (((hinf_controller_P.Dd[0] * rtb_Saturation
          + hinf_controller_P.Dd[1] * rtb_HILReadEncoderTimebase_o1) + Eref) +
          rtb_Saturation * 2.0) + 0.5 * hinf_controller_B.TransferFcn;
        for (i = 0; i <= 4; i += 2) {
          tmp_3 = _mm_loadu_pd(&tmp_0[i]);
          tmp_4 = _mm_loadu_pd(&tmp_1[i]);
          _mm_storeu_pd(&hinf_controller_DW.xk[i], _mm_add_pd(tmp_3, tmp_4));
        }
      } else {
        /* '<S1>:1:67' */
        /* '<S1>:1:68' */
        rtb_Saturation = cos(hinf_controller_mod(hinf_controller_B.Gain1 +
          3.1415926535897931) - 3.1415926535897931);
        rtb_HILReadEncoderTimebase_o1 = hinf_controller_B.TransferFcn1 *
          hinf_controller_B.TransferFcn1 * 6.6565E-5 + (1.0 - rtb_Saturation) *
          0.015186;

        /* '<S1>:1:69' */
        rtb_Saturation *= hinf_controller_B.TransferFcn1;

        /* '<S1>:1:69' */
        /* '<S1>:1:70' */
        Eref = 1.05 * hinf_controller_P.Er;
        if (rtb_HILReadEncoderTimebase_o1 < Eref) {
          /* '<S1>:1:71' */
          rtb_HILReadEncoderTimebase_o1 = (Eref - rtb_HILReadEncoderTimebase_o1)
            * hinf_controller_P.mu * (rtb_Saturation / (fabs(rtb_Saturation) +
            0.05));
        } else {
          /* '<S1>:1:71' */
          rtb_HILReadEncoderTimebase_o1 = 0.0;
        }

        /* '<S1>:1:72' */
        /* '<S1>:1:73' */
        hinf_controller_B.Voltage = fmin(fmax((rtb_HILReadEncoderTimebase_o1 -
          0.5 * hinf_controller_B.Gain) - 0.05 * hinf_controller_B.TransferFcn,
          -6.0), 6.0);
      }
    }

    /* End of MATLAB Function: '<Root>/MATLAB Function' */

    /* Saturate: '<Root>/Saturation' */
    if (hinf_controller_B.Voltage > hinf_controller_P.Saturation_UpperSat) {
      rtb_Saturation = hinf_controller_P.Saturation_UpperSat;
    } else if (hinf_controller_B.Voltage < hinf_controller_P.Saturation_LowerSat)
    {
      rtb_Saturation = hinf_controller_P.Saturation_LowerSat;
    } else {
      rtb_Saturation = hinf_controller_B.Voltage;
    }

    /* End of Saturate: '<Root>/Saturation' */

    /* S-Function (hil_write_analog_block): '<Root>/HIL Write Analog' */

    /* S-Function Block: hinf_controller/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      result = hil_write_analog(hinf_controller_DW.HILInitialize_Card,
        &hinf_controller_P.HILWriteAnalog_channels, 1, &rtb_Saturation);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      }
    }
  }
}

/* Model update function */
void hinf_controller_update(void)
{
  if (rtmIsMajorTimeStep(hinf_controller_M)) {
    rt_ertODEUpdateContinuousStates(&hinf_controller_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++hinf_controller_M->Timing.clockTick0)) {
    ++hinf_controller_M->Timing.clockTickH0;
  }

  hinf_controller_M->Timing.t[0] = rtsiGetSolverStopTime
    (&hinf_controller_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.002s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++hinf_controller_M->Timing.clockTick1)) {
      ++hinf_controller_M->Timing.clockTickH1;
    }

    hinf_controller_M->Timing.t[1] = hinf_controller_M->Timing.clockTick1 *
      hinf_controller_M->Timing.stepSize1 +
      hinf_controller_M->Timing.clockTickH1 *
      hinf_controller_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void hinf_controller_derivatives(void)
{
  XDot_hinf_controller_T *_rtXdot;
  _rtXdot = ((XDot_hinf_controller_T *) hinf_controller_M->derivs);

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = hinf_controller_P.TransferFcn_A *
    hinf_controller_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += hinf_controller_B.Gain;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn1' */
  _rtXdot->TransferFcn1_CSTATE = hinf_controller_P.TransferFcn1_A *
    hinf_controller_X.TransferFcn1_CSTATE;
  _rtXdot->TransferFcn1_CSTATE += hinf_controller_B.Gain1;
}

/* Model initialize function */
void hinf_controller_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: hinf_controller/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("qube_servo3_usb", "0",
                      &hinf_controller_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(hinf_controller_DW.HILInitialize_Card,
      "deadband_compensation=0;pwm_en=0;enc0_velocity=3.0;enc1_velocity=3.0;min_diode_compensation=0.3;max_diode_compensation=1.5;",
      124);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(hinf_controller_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      return;
    }

    if ((hinf_controller_P.HILInitialize_AIPStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_AIPEnter && is_switching)) {
      result = hil_set_analog_input_ranges(hinf_controller_DW.HILInitialize_Card,
        &hinf_controller_P.HILInitialize_AIChannels, 1U,
        &hinf_controller_P.HILInitialize_AILow,
        &hinf_controller_P.HILInitialize_AIHigh);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if ((hinf_controller_P.HILInitialize_AOPStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_AOPEnter && is_switching)) {
      result = hil_set_analog_output_ranges
        (hinf_controller_DW.HILInitialize_Card,
         &hinf_controller_P.HILInitialize_AOChannels, 1U,
         &hinf_controller_P.HILInitialize_AOLow,
         &hinf_controller_P.HILInitialize_AOHigh);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if ((hinf_controller_P.HILInitialize_AOStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_AOEnter && is_switching)) {
      result = hil_write_analog(hinf_controller_DW.HILInitialize_Card,
        &hinf_controller_P.HILInitialize_AOChannels, 1U,
        &hinf_controller_P.HILInitialize_AOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if (hinf_controller_P.HILInitialize_AOReset) {
      result = hil_watchdog_set_analog_expiration_state
        (hinf_controller_DW.HILInitialize_Card,
         &hinf_controller_P.HILInitialize_AOChannels, 1U,
         &hinf_controller_P.HILInitialize_AOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    result = hil_set_digital_directions(hinf_controller_DW.HILInitialize_Card,
      NULL, 0U, &hinf_controller_P.HILInitialize_DOChannels, 1U);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
      return;
    }

    if ((hinf_controller_P.HILInitialize_DOStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_DOEnter && is_switching)) {
      result = hil_write_digital(hinf_controller_DW.HILInitialize_Card,
        &hinf_controller_P.HILInitialize_DOChannels, 1U, (t_boolean *)
        &hinf_controller_P.HILInitialize_DOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if (hinf_controller_P.HILInitialize_DOReset) {
      result = hil_watchdog_set_digital_expiration_state
        (hinf_controller_DW.HILInitialize_Card,
         &hinf_controller_P.HILInitialize_DOChannels, 1U, (const t_digital_state
          *) &hinf_controller_P.HILInitialize_DOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if ((hinf_controller_P.HILInitialize_EIPStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_EIPEnter && is_switching)) {
      hinf_controller_DW.HILInitialize_QuadratureModes[0] =
        hinf_controller_P.HILInitialize_EIQuadrature;
      hinf_controller_DW.HILInitialize_QuadratureModes[1] =
        hinf_controller_P.HILInitialize_EIQuadrature;
      result = hil_set_encoder_quadrature_mode
        (hinf_controller_DW.HILInitialize_Card,
         hinf_controller_P.HILInitialize_EIChannels, 2U,
         (t_encoder_quadrature_mode *)
         &hinf_controller_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if ((hinf_controller_P.HILInitialize_EIStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_EIEnter && is_switching)) {
      hinf_controller_DW.HILInitialize_InitialEICounts[0] =
        hinf_controller_P.HILInitialize_EIInitial;
      hinf_controller_DW.HILInitialize_InitialEICounts[1] =
        hinf_controller_P.HILInitialize_EIInitial;
      result = hil_set_encoder_counts(hinf_controller_DW.HILInitialize_Card,
        hinf_controller_P.HILInitialize_EIChannels, 2U,
        &hinf_controller_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if ((hinf_controller_P.HILInitialize_OOStart && !is_switching) ||
        (hinf_controller_P.HILInitialize_OOEnter && is_switching)) {
      result = hil_write_other(hinf_controller_DW.HILInitialize_Card,
        hinf_controller_P.HILInitialize_OOChannels, 3U,
        hinf_controller_P.HILInitialize_OOInitial);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }

    if (hinf_controller_P.HILInitialize_OOReset) {
      result = hil_watchdog_set_other_expiration_state
        (hinf_controller_DW.HILInitialize_Card,
         hinf_controller_P.HILInitialize_OOChannels, 3U,
         hinf_controller_P.HILInitialize_OOWatchdog);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<Root>/HIL Read Encoder Timebase' */

  /* S-Function Block: hinf_controller/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader
      (hinf_controller_DW.HILInitialize_Card,
       hinf_controller_P.HILReadEncoderTimebase_SamplesI,
       hinf_controller_P.HILReadEncoderTimebase_Channels, 2,
       &hinf_controller_DW.HILReadEncoderTimebase_Task);
    if (result >= 0) {
      result = hil_task_set_buffer_overflow_mode
        (hinf_controller_DW.HILReadEncoderTimebase_Task, (t_buffer_overflow_mode)
         (hinf_controller_P.HILReadEncoderTimebase_Overflow - 1));
    }

    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
    }
  }

  {
    int32_T i;

    /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn' */
    hinf_controller_X.TransferFcn_CSTATE = 0.0;

    /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn1' */
    hinf_controller_X.TransferFcn1_CSTATE = 0.0;

    /* SystemInitialize for MATLAB Function: '<Root>/MATLAB Function' */
    hinf_controller_DW.mode = 0.0;
    hinf_controller_DW.mode_not_empty = true;
    hinf_controller_DW.k = 0.0;
    hinf_controller_DW.k_not_empty = true;
    hinf_controller_DW.tripped = 0.0;
    hinf_controller_DW.tripped_not_empty = true;
    for (i = 0; i < 6; i++) {
      hinf_controller_DW.xk[i] = 0.0;
    }

    hinf_controller_DW.xk_not_empty = true;
    hinf_controller_DW.th_ref = 0.0;
    hinf_controller_DW.th_ref_not_empty = true;
    hinf_controller_DW.doneDoubleBufferReInit = false;
    hinf_controller_DW.sfEvent = hinf_controller_CALL_EVENT;

    /* End of SystemInitialize for MATLAB Function: '<Root>/MATLAB Function' */
  }
}

/* Model terminate function */
void hinf_controller_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: hinf_controller/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_digital_outputs = 0;
    t_uint32 num_final_other_outputs = 0;
    hil_task_stop_all(hinf_controller_DW.HILInitialize_Card);
    hil_monitor_stop_all(hinf_controller_DW.HILInitialize_Card);
    is_switching = false;
    if ((hinf_controller_P.HILInitialize_AOTerminate && !is_switching) ||
        (hinf_controller_P.HILInitialize_AOExit && is_switching)) {
      num_final_analog_outputs = 1U;
    } else {
      num_final_analog_outputs = 0;
    }

    if ((hinf_controller_P.HILInitialize_DOTerminate && !is_switching) ||
        (hinf_controller_P.HILInitialize_DOExit && is_switching)) {
      num_final_digital_outputs = 1U;
    } else {
      num_final_digital_outputs = 0;
    }

    if ((hinf_controller_P.HILInitialize_OOTerminate && !is_switching) ||
        (hinf_controller_P.HILInitialize_OOExit && is_switching)) {
      num_final_other_outputs = 3U;
    } else {
      num_final_other_outputs = 0;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_digital_outputs > 0
        || num_final_other_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(hinf_controller_DW.HILInitialize_Card
                         , &hinf_controller_P.HILInitialize_AOChannels,
                         num_final_analog_outputs
                         , NULL, 0
                         , &hinf_controller_P.HILInitialize_DOChannels,
                         num_final_digital_outputs
                         , hinf_controller_P.HILInitialize_OOChannels,
                         num_final_other_outputs
                         , &hinf_controller_P.HILInitialize_AOFinal
                         , NULL
                         , (t_boolean *)
                         &hinf_controller_P.HILInitialize_DOFinal
                         , hinf_controller_P.HILInitialize_OOFinal
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(hinf_controller_DW.HILInitialize_Card,
            &hinf_controller_P.HILInitialize_AOChannels,
            num_final_analog_outputs, &hinf_controller_P.HILInitialize_AOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_digital_outputs > 0) {
          local_result = hil_write_digital(hinf_controller_DW.HILInitialize_Card,
            &hinf_controller_P.HILInitialize_DOChannels,
            num_final_digital_outputs, (t_boolean *)
            &hinf_controller_P.HILInitialize_DOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_other_outputs > 0) {
          local_result = hil_write_other(hinf_controller_DW.HILInitialize_Card,
            hinf_controller_P.HILInitialize_OOChannels, num_final_other_outputs,
            hinf_controller_P.HILInitialize_OOFinal);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(hinf_controller_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(hinf_controller_DW.HILInitialize_Card);
    hil_monitor_delete_all(hinf_controller_DW.HILInitialize_Card);
    hil_close(hinf_controller_DW.HILInitialize_Card);
    hinf_controller_DW.HILInitialize_Card = NULL;
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  hinf_controller_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  hinf_controller_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  hinf_controller_initialize();
}

void MdlTerminate(void)
{
  hinf_controller_terminate();
}

/* Registration function */
RT_MODEL_hinf_controller_T *hinf_controller(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)hinf_controller_M, 0,
                sizeof(RT_MODEL_hinf_controller_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&hinf_controller_M->solverInfo,
                          &hinf_controller_M->Timing.simTimeStep);
    rtsiSetTPtr(&hinf_controller_M->solverInfo, &rtmGetTPtr(hinf_controller_M));
    rtsiSetStepSizePtr(&hinf_controller_M->solverInfo,
                       &hinf_controller_M->Timing.stepSize0);
    rtsiSetdXPtr(&hinf_controller_M->solverInfo, &hinf_controller_M->derivs);
    rtsiSetContStatesPtr(&hinf_controller_M->solverInfo, (real_T **)
                         &hinf_controller_M->contStates);
    rtsiSetNumContStatesPtr(&hinf_controller_M->solverInfo,
      &hinf_controller_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&hinf_controller_M->solverInfo,
      &hinf_controller_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&hinf_controller_M->solverInfo,
      &hinf_controller_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&hinf_controller_M->solverInfo,
      &hinf_controller_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&hinf_controller_M->solverInfo, (boolean_T**)
      &hinf_controller_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&hinf_controller_M->solverInfo, (&rtmGetErrorStatus
      (hinf_controller_M)));
    rtsiSetRTModelPtr(&hinf_controller_M->solverInfo, hinf_controller_M);
  }

  rtsiSetSimTimeStep(&hinf_controller_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&hinf_controller_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&hinf_controller_M->solverInfo, false);
  hinf_controller_M->intgData.y = hinf_controller_M->odeY;
  hinf_controller_M->intgData.f[0] = hinf_controller_M->odeF[0];
  hinf_controller_M->intgData.f[1] = hinf_controller_M->odeF[1];
  hinf_controller_M->intgData.f[2] = hinf_controller_M->odeF[2];
  hinf_controller_M->intgData.f[3] = hinf_controller_M->odeF[3];
  hinf_controller_M->contStates = ((real_T *) &hinf_controller_X);
  hinf_controller_M->contStateDisabled = ((boolean_T *) &hinf_controller_XDis);
  hinf_controller_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&hinf_controller_M->solverInfo, (void *)
                    &hinf_controller_M->intgData);
  rtsiSetSolverName(&hinf_controller_M->solverInfo,"ode4");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = hinf_controller_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    hinf_controller_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    hinf_controller_M->Timing.sampleTimes =
      (&hinf_controller_M->Timing.sampleTimesArray[0]);
    hinf_controller_M->Timing.offsetTimes =
      (&hinf_controller_M->Timing.offsetTimesArray[0]);

    /* task periods */
    hinf_controller_M->Timing.sampleTimes[0] = (0.0);
    hinf_controller_M->Timing.sampleTimes[1] = (0.002);

    /* task offsets */
    hinf_controller_M->Timing.offsetTimes[0] = (0.0);
    hinf_controller_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(hinf_controller_M, &hinf_controller_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = hinf_controller_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    hinf_controller_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(hinf_controller_M, -1);
  hinf_controller_M->Timing.stepSize0 = 0.002;
  hinf_controller_M->Timing.stepSize1 = 0.002;

  /* External mode info */
  hinf_controller_M->Sizes.checksums[0] = (605620885U);
  hinf_controller_M->Sizes.checksums[1] = (836378721U);
  hinf_controller_M->Sizes.checksums[2] = (2338716768U);
  hinf_controller_M->Sizes.checksums[3] = (2529738668U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    hinf_controller_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(hinf_controller_M->extModeInfo,
      &hinf_controller_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(hinf_controller_M->extModeInfo,
                        hinf_controller_M->Sizes.checksums);
    rteiSetTPtr(hinf_controller_M->extModeInfo, rtmGetTPtr(hinf_controller_M));
  }

  hinf_controller_M->solverInfoPtr = (&hinf_controller_M->solverInfo);
  hinf_controller_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&hinf_controller_M->solverInfo, 0.002);
  rtsiSetSolverMode(&hinf_controller_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  hinf_controller_M->blockIO = ((void *) &hinf_controller_B);
  (void) memset(((void *) &hinf_controller_B), 0,
                sizeof(B_hinf_controller_T));

  /* parameters */
  hinf_controller_M->defaultParam = ((real_T *)&hinf_controller_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &hinf_controller_X;
    hinf_controller_M->contStates = (x);
    (void) memset((void *)&hinf_controller_X, 0,
                  sizeof(X_hinf_controller_T));
  }

  /* disabled states */
  {
    boolean_T *xdis = (boolean_T *) &hinf_controller_XDis;
    hinf_controller_M->contStateDisabled = (xdis);
    (void) memset((void *)&hinf_controller_XDis, 0,
                  sizeof(XDis_hinf_controller_T));
  }

  /* states (dwork) */
  hinf_controller_M->dwork = ((void *) &hinf_controller_DW);
  (void) memset((void *)&hinf_controller_DW, 0,
                sizeof(DW_hinf_controller_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    hinf_controller_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 22;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  hinf_controller_M->Sizes.numContStates = (2);/* Number of continuous states */
  hinf_controller_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  hinf_controller_M->Sizes.numY = (0); /* Number of model outputs */
  hinf_controller_M->Sizes.numU = (0); /* Number of model inputs */
  hinf_controller_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  hinf_controller_M->Sizes.numSampTimes = (2);/* Number of sample times */
  hinf_controller_M->Sizes.numBlocks = (12);/* Number of blocks */
  hinf_controller_M->Sizes.numBlockIO = (5);/* Number of block outputs */
  hinf_controller_M->Sizes.numBlockPrms = (175);/* Sum of parameter "widths" */
  return hinf_controller_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
