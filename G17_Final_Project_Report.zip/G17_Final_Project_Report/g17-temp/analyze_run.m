function M = analyze_run(file, test)
% M = analyze_run('roa_lqr_10deg_r1.mat', 'roa')
% Loads one saved run, plots it, prints the metrics for that test and saves the figure as PNG.
%   test = 'swingup' | 'roa' | 'disturb' | 'quiet'
% The .mat file comes from ONE To Host File block fed by a Mux of [x (4 signals); V (1 signal)]
% (rows: time, theta, alpha, theta_dot, alpha_dot, V). Old To Workspace files also still work.

    TRIM = 0.007;  VSAT = 10;  ARM_TIME = 8.0;  EPS = 0.35;   % ARM_TIME must match the controllers

    %% ---- no arguments: pick the file and test type from a dialog ----
    M = struct();
    if nargin < 1
        [f, p] = uigetfile('*.mat', 'Pick a saved run');
        if isequal(f, 0), return; end
        file = fullfile(p, f);
    end
    if nargin < 2
        types = {'swingup', 'roa', 'disturb', 'quiet'};
        i = listdlg('ListString', types, 'SelectionMode', 'single', 'PromptString', 'Test type:');
        if isempty(i), return; end
        test = types{i};
    end

    %% ---- load ----
    S = load(file);  fn = fieldnames(S);
    ix = find(strncmp(fn, 'x_log', 5), 1);
    if ~isempty(ix)                                   % To Workspace (Timeseries) format
        xl = S.(fn{ix});  ul = S.(fn{find(strncmp(fn, 'u_log', 5), 1)});
        t = xl.Time(:);
        X = squeeze(xl.Data);  if size(X,2) ~= 4, X = X.'; end
        V = squeeze(ul.Data);  V = V(:);
        if numel(V) ~= numel(t), V = interp1(ul.Time(:), V, t, 'previous', 'extrap'); end
    else                                              % To Host File format: [time; x(4); V]
        D = double(S.(fn{1}));
        if size(D,1) ~= 6 && size(D,2) == 6, D = D.'; end
        if size(D,1) ~= 6
            error('Expected 6 rows [t; theta; alpha; theta_dot; alpha_dot; V], got %dx%d', size(D,1), size(D,2));
        end
        t = D(1,:).';  X = D(2:5,:).';  V = D(6,:).';
    end
    th    = X(:,1);
    a_up  = mod(X(:,2) + TRIM, 2*pi) - pi;     % 0 = upright
    a_bot = mod(X(:,2) + pi,   2*pi) - pi;     % 0 = hanging
    ad    = X(:,4);
    dt    = median(diff(t));
    [~, name] = fileparts(file);
    M = struct('name', name);

    %% ---- plot ----
    f = figure('Name', name, 'Color', 'w');
    subplot(3,1,1); plot(t, rad2deg(th));   grid on; ylabel('\theta (deg)'); title(strrep(name, '_', '\_'));
    subplot(3,1,2); plot(t, rad2deg(a_up)); grid on; ylabel('\alpha (deg, 0 = up)');
    subplot(3,1,3); plot(t, V); grid on; ylabel('V (V)'); xlabel('t (s)');

    %% ---- metrics ----
    switch test
        case 'swingup'
            i_push = find(abs(a_bot) > deg2rad(3), 1);
            ic = capture_idx(a_up, EPS, round(2/dt));
            M.caught = ~isnan(ic);
            if M.caught
                M.t_capture = t(ic) - t(i_push);
                M.swings    = floor(sum(abs(diff(sign(ad(i_push:ic)))) > 0)/2);
                M.max_V     = max(abs(V(i_push:ic)));
            end

        case 'roa'          % recorded with ROA_TEST = 1
            i0 = find(t >= ARM_TIME, 1);
            M.tilt_deg = abs(rad2deg(a_up(i0)));
            last = t >= t(end) - 2;
            M.caught = max(abs(a_up(last))) < deg2rad(20);
            if M.caught
                aa = a_up(i0:end);  tt = t(i0:end) - t(i0);
                iout = find(abs(aa) > deg2rad(2), 1, 'last');
                if isempty(iout), M.settle_s = 0; else, M.settle_s = tt(iout); end
                M.overshoot_deg = max(0, rad2deg(max(-sign(a_up(i0))*aa)));
                M.arm_peak_deg  = rad2deg(max(abs(th(i0:end) - th(i0))));
                M.peak_V        = max(abs(V(i0:end)));
            end

        case 'disturb'      % one tap while balancing
            ic = capture_idx(a_up, EPS, round(2/dt));
            it = find(t > t(ic) + 2 & abs(a_up) > deg2rad(3), 1);
            w  = t >= t(it) & t <= t(it) + 5;
            aa = a_up(w);  tt = t(w) - t(it);
            M.fell          = any(abs(aa) > 0.6);
            M.peak_alpha_deg = rad2deg(max(abs(aa)));
            M.arm_dev_deg    = rad2deg(max(abs(th(w) - th(it))));
            M.peak_V         = max(abs(V(w)));
            if ~M.fell
                iout = find(abs(aa) > deg2rad(1), 1, 'last');  M.recovery_s = tt(iout);
            end

        case 'quiet'        % 20 s untouched balance
            ic = capture_idx(a_up, EPS, round(2/dt));
            w  = t >= t(ic) + 3 & t <= t(end) - 0.5;
            v  = V(w);
            M.rms_V        = sqrt(mean(v.^2));
            M.peak_V       = max(abs(v));
            M.sat_pct      = 100*mean(abs(v) >= 0.98*VSAT);
            M.rms_alpha_deg = rad2deg(sqrt(mean(a_up(w).^2)));
            M.std_theta_deg = rad2deg(std(th(w)));
            vv = v - mean(v);  n = numel(vv);  Y = abs(fft(vv))/n;  kk = 2:floor(n/2);
            fr = (kk-1)'/(n*dt);  P = 2*Y(kk);
            M.hf_pct = 100*sum(P(fr > 20).^2)/max(sum(P(fr > 0.5).^2), eps);
            figure('Name', [name '_fft'], 'Color', 'w');
            semilogy(fr, P); grid on; xlabel('Frequency (Hz)'); ylabel('|V(f)|');
            title(['Voltage spectrum: ' strrep(name, '_', '\_')]);
            saveas(gcf, [name '_fft.png']);
        otherwise
            error('unknown test type');
    end
    saveas(f, [name '.png']);
    disp(M);
end

function ic = capture_idx(a_up, eps_rad, n)
% first sample after which |alpha_up| stays < eps for n samples
    in = abs(a_up(:)) < eps_rad;  N = numel(in);  ic = NaN;
    cs = cumsum([0; ~in]);
    ok = (cs(n+1:N+1) - cs(1:N-n+1)) == 0;
    i = find(ok, 1);  if ~isempty(i), ic = i; end
end